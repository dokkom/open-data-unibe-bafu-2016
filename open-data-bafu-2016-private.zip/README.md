#Forschungslandschaft Schweiz
@date: 24.5.2016

@authors: Dominic Kohler, Flurin Truebner

##Beschreibung
Diese Visualisierung bietet eine Übersicht zu den Umwelt Forschungsgruppen der Schweiz. Nach Selektierung der Hauptthemen werden die Forschunggruppen, mit Namen und Link zu der Forschungsseite, an Ihrem Standort auf der [geo.admin Karte][id] dargestellt.



![Alt text](open_data_de_scrn.png?raw=true "Screenshot UI")

[id]: http://www.geo.admin.ch/

Die Applikation entstand im Rahmen der Open Data Vorlesung während dem Fruehlingssemester 2016 an der Universität Bern.